Binome : Hugues Charbon et C�me Burguburu

t�ches:
Message d'accueil Hugues
Page de recherche C�me
OAuth(Connexion Google) C�me
Add Training 	Hugues
search		C�me
result		C�me
personnal data Hugues

url:
http://coachengine-1147.appspot.com/

Questions r�alis�es:
Toutes les questions ont �t� r�alis�es sauf la partie 7

Autre:
UI completement responsive avec Bootstrap
R�cupp�ration des donn�es du profil Google+ de l'utilisateur